#ifndef BUYER_H
#define BUYER_H

#endif // BUYER_H
